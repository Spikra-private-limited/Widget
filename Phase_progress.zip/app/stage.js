var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
var Name = "Meenakshi Hi";
var Email = "theola-frey@frey.com";
var converted_contact;
/*var Company = document.getElementbyNames("societa");
var Email = document.getElementbyNames("E-mail");
var Country = document.getElementByNames("Nazione");
var Nazione = country.options[country.selectedIndex].value;
var Message = document.getElementbyNames("Messaggio");*/

var url1="https://accounts.zoho.com/oauth/v2/token";
	var xhr1 = new XMLHttpRequest();
	xhr1.responseType="json";
   xhr1.open("POST", url1, false);
   xhr1.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
   xhr1.send("grant_type=refresh_token&refresh_token=1000.2ef227f00d96c906e7e5f3bb912cabab.9f92e89dc021d0e5c9faf3ad70aa2127&client_id=1000.K5DYWI3OE9I46JD6DDC3R15BIOACZF&client_secret=bdc3e899152fa7c94cc2af40266be934aec840a724");
    var tokens=JSON.parse(xhr1.responseText);
	if(tokens.access_token==null)
	{
		window.alert("Please try again after a minute");
	}
	else
	{
	var oauth="Zoho-oauthtoken "+(tokens.access_token);
	//console.log(oauth);

	 var url2="https://www.zohoapis.com/crm/v2/Leads/search?criteria=(Email:equals:"+Email+")";
	 var xhr2 = new XMLHttpRequest();
	 xhr2.open("GET", url2, false);
     xhr2.setRequestHeader('Authorization', oauth);	 
     xhr2.send();
	 console.log(xhr2.responseText);
	 if(xhr2.responseText=="")
	 {
		 var url="https://www.zohoapis.com/crm/v2/Contacts";
var xhr = new XMLHttpRequest();
xhr.responseType="json";
xhr.open("POST", url, false);
xhr.setRequestHeader('Authorization', oauth);
xhr.send(JSON.stringify({"data": [
        {
            
			"Last_Name": Name,
            "Email": Email
			/*"Email": Email
            "Company": Company,            
            "State": Nazione,
			"Note": Message*/
}],
"trigger": [
        "approval",
        "workflow",
        "blueprint"
    ]})); 


console.log(xhr.responseText);
	 }
	 else
	 {
	 var lead_search=(JSON.parse(xhr2.responseText));
	 console.log(lead_search.data[0].id);
	 console.log(lead_search.data[0].Owner.name);
	  var url="https://www.zohoapis.com/crm/v2/Leads/"+lead_search.data[0].id+"/actions/convert";
var xhr = new XMLHttpRequest();
xhr.responseType="json";
xhr.open("POST", url, false);
xhr.setRequestHeader('Authorization', oauth);
xhr.send(JSON.stringify({"data": [
			{
			"Owner":lead_search.data[0].Owner.id
			/*"Email": Email
            "Company": Company,            
            "State": Nazione,
			"Note": Message*/
			
}],
"trigger": [
        "approval",
        "workflow",
        "blueprint"
    ]})); 


converted_contact=JSON.parse(xhr.responseText);
cc_id=converted_contact.data[0].Contacts;
 var url3="https://www.zohoapis.com/crm/v2/Contacts/"+cc_id;
var xhr3 = new XMLHttpRequest();
xhr3.responseType="json";
xhr3.open("PUT", url3, false);
xhr3.setRequestHeader('Authorization', oauth);
xhr3.send(JSON.stringify({"data": [
			{
			"Owner":lead_search.data[0].Owner.id,
			"Last_Name":lead_search.data[0].Last_Name
			/*"Email": Email
            "Company": Company,            
            "State": Nazione,
			"Note": Message*/
			
}],
"trigger": [
        "approval",
        "workflow",
        "blueprint"
    ]})); 
console.log(xhr3.responseText);
	 }
	}