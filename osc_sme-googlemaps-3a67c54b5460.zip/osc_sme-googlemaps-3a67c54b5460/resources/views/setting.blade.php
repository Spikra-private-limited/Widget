@extends('google.master')

@section('button_name', 'Add To Lead')

@section('map-content')
    <div class="container">
        <div class="col-lg-10 col-lg-offset-2">
            <h2>Google Map Settings</h2>
            <hr>
            <span id="msgDom" style="display: none;">You have successfully updated the setting.</span>
            <table class="table table-striped table-dark">
                <tr>
                    <td width="20%">Google API Key</td>
                    <td width="80%" class="slimField">
                        <input class="form-control" id="google_api_key">
                    </td>
                </tr>
                <tr>
                    <td width="20%">Office Location</td>
                    <td width="80%" class="slimField">
                        <select class="custom-select" id="officeAddSelect" style="width: 90%">

                        </select>
                        <button class="btn btn-sm btn-info" id="location_add"><strong title="Add New Address">+</strong></button> <button class="btn btn-sm btn-danger" id="removeOfficeAdd"><strong title="Remove This Selected Address">x</strong></button>
                    </td>
                </tr>
                <tr>
                    <td width="20%"></td>
                    <td width="80%">
                        <button class="btn btn-default" id="updateSetting">Update Setting</button>
                    </td>
                </tr>

            </table>
        </div>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="location_add_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Office Address</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <table id="addressModal" class="table table-striped table-dark">
                        <tr>
                            <td class="slimField">
                                <input class="form-control" id="street_number" placeholder="Street No">
                            </td>
                            <td class="wideField" colspan="2">
                                <input class="form-control" id="route" placeholder="Street Name">
                            </td>
                        </tr>
                        <tr>
                            <td class="wideField" colspan="3">
                                <input class="form-control" id="locality" placeholder="City Name">
                            </td>
                        </tr>
                        <tr>
                            <td class="slimField">
                                <input class="form-control" id="administrative_area_level_1" placeholder="State Name">
                            </td>
                            <td class="wideField">
                                <input class="form-control" id="postal_code" placeholder="Postal Code">
                            </td>
                        </tr>
                        <tr>
                            <td class="wideField" colspan="3">
                                <input class="form-control" id="country" placeholder="Country Name">
                            </td>
                        </tr>

                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="addOffice">Save</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('javascript_module')

    <script type="text/javascript">
        $(document).ready(function (e) {

            ZOHO.embeddedApp.init().then(function(){

                ZOHO.CRM.API.getOrgVariable("Google_Api_Key").then(function(data){
                    var newOrg 		= (data.Success);
                    google_api_key 	= newOrg.Content;
                    if(google_api_key != null){
                        $("#google_api_key").val(google_api_key);
                    }
                });

                ZOHO.CRM.API.getOrgVariable("Office_Location").then(function(data){
                    var newOrg 		= (data.Success);
                    Office_Location 	= newOrg.Content;
                    if(Office_Location != null){
                        officeLocationJson = JSON.parse(Office_Location);

                        var ofc_index = 1;
                        var option = '';
                        while (true) {
                            var ofc_add_obj = '';

                            if (!officeLocationJson.hasOwnProperty(ofc_index)) {
                                break;
                            }

                            // Office Location Add
                            ofc_add_obj = officeLocationJson[ofc_index];
                            console.log();
                            var add_string = ((ofc_add_obj.Street.length > 0) ? ofc_add_obj.Street+', ' : '') + ((ofc_add_obj.City.length > 0) ? ofc_add_obj.City+', ' : '') + ((ofc_add_obj.State.length > 0) ? ofc_add_obj.State+', ' : '') + ((ofc_add_obj.Country.length > 0) ? ofc_add_obj.Country : '');
                            add_string = add_string.replace(/,\s*$/, "");
                            option += "<option value='"+JSON.stringify(ofc_add_obj)+"'>"+add_string+"</option>";

                            ofc_index++;

                        }

                        $('#officeAddSelect').html(option);
                    }
                });


            });

            $(document).on('click','#location_add',function (e) {
                $("#addressModal input").val('');
                $('#location_add_modal').modal('show');
            });

            $(document).on('click', '#addOffice', function (e) {
                var addressInfo = {};
                var officeLocation = {};
                var street_no   = $('#street_number').val();
                var route       = $('#route').val();
                var state       = $('#administrative_area_level_1').val();
                var city        = $('#locality').val();
                var postal_code = $('#postal_code').val();
                var country     = $('#country').val();

                street_no = street_no + ' ' + route;

                addressInfo = {
                    'Street'    : street_no,
                    'State'     : state,
                    'City'      : city,
                    'Zip_Code'  : postal_code,
                    'Country'   : country,
                };

                var option = '';
                var ofc_index = 1;
                $('#officeAddSelect option').each(function () {
                    option += "<option value='"+$(this).val()+"'>"+$(this).text()+"</option>";
                    officeLocation[ofc_index++] = JSON.parse($(this).val());
                });

                var add_string = ((street_no.length>0) ? street_no+', ' : '') + ((city.length>0) ? city+', ' : '') + ((state.length>0) ? state+', ' : '') + ((country.length>0) ? country : '');
                add_string = add_string.replace(/,\s*$/, "");
                option += "<option value='"+JSON.stringify(addressInfo)+"'>"+add_string+"</option>";

                officeLocation[ofc_index] = addressInfo;

                $('#officeAddSelect').html(option);

                ZOHO.CRM.CONNECTOR.invokeAPI("crm.set",{"apiname":"Office_Location","value":officeLocation})
                    .then(function(data){
                        var response = $.parseJSON(data);
                        if(response.status_code == 200){
                            $('#msgDom').html('You have successfully added the new office location.');

                        }else{
                            $('#msgDom').html('Failed to add new office location.');
                        }
                        $('#msgDom').show();
                        setInterval(function (e) {
                            $('#msgDom').hide();
                        }, 3000)
                    });

                $('#location_add_modal').modal('hide');
            });


            $(document).on('click', '#removeOfficeAdd', function () {
                if (confirm("Are you sure want to delete this Office Location?")) {
                    $('#officeAddSelect option:selected').remove();

                    var officeLocation = {};
                    var ofc_index = 1;
                    $('#officeAddSelect option').each(function () {
                        officeLocation[ofc_index++] = JSON.parse($(this).val());
                    });

                    ZOHO.CRM.CONNECTOR.invokeAPI("crm.set",{"apiname":"Office_Location","value":officeLocation})
                        .then(function(data){
                            var response = $.parseJSON(data);
                            if(response.status_code == 200){
                                $('#msgDom').html('Removed Office location successfully.');

                            }else{
                                $('#msgDom').html('Failed to remove office location.');
                            }
                            $('#msgDom').show();
                            setInterval(function (e) {
                                $('#msgDom').hide();
                            }, 3000)
                        });
                }
            });


            $(document).on('click', '#updateSetting', function (e) {
                e.preventDefault();
                var google_api_key = $('#google_api_key').val();
                var officeLocation = {};
                var ofc_index = 1;
                $('#officeAddSelect option').each(function () {
                    officeLocation[ofc_index++] = JSON.parse($(this).val());
                });


                ZOHO.CRM.CONNECTOR.invokeAPI("crm.set",{"apiname":"Google_Api_Key","value":google_api_key})
                    .then(function(data){
                        var response = $.parseJSON(data);
                        if(response.status_code == 200){
                            ZOHO.CRM.CONNECTOR.invokeAPI("crm.set",{"apiname":"Office_Location","value":officeLocation})
                                .then(function(data){
                                    var response = $.parseJSON(data);
                                    if(response.status_code == 200){
                                        $('#msgDom').html('You have successfully updated the settings.');

                                    }else{
                                        $('#msgDom').html('Update Failed. Please try again.');
                                    }
                                    $('#msgDom').show();
                                    setInterval(function (e) {
                                        $('#msgDom').hide();
                                    }, 3000)
                                });
                        }
                    })



            });

        });
    </script>
@endsection