<!doctype html>
<html lang="{{ app()->getLocale() }}">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title>Google Maps Project</title>
  </head>
  <body class="bg-light">


      @yield('map-content')
    </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    
    <script id="xbestos"  async defer></script>
    
    <script src="js/zlib/ZohoEmbededAppSDK.min.js"></script>
    {{--<script src="js/zoho-master-client.js"></script>--}}

    @yield('javascript_module')

    <script>
      // This example displays an address form, using the autocomplete feature
      // of the Google Places API to help users fill in the information.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      var placeSearch, autocomplete, office_location;
      var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            (document.getElementById('autocomplete')),
            {types: ['geocode']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
      }

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();

        if ($('#officeAddSelect').val()) {
           office_location = $('#officeAddSelect option:selected').text();
        }

        calculateDistances(place.formatted_address);

        for (var component in componentForm) {
          document.getElementById(component).value = '';
          document.getElementById(component).disabled = false;
        }

        document.getElementById('latitude').value = '';
        document.getElementById('latitude').disabled = false;
        document.getElementById('latitude').value = place.geometry.location.lat();

        document.getElementById('longitude').value = '';
        document.getElementById('longitude').disabled = false;
        document.getElementById('longitude').value = place.geometry.location.lng();

        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
          }
        }
      }

      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }


    function calculateDistances(destinationAddr) {
      var service = new google.maps.DistanceMatrixService();
      var location = (office_location) ? office_location: "";
      if (location == "") {
        alert("Office Location is not selected. So you don't get distance and duration.");
        return false;
      }
      service.getDistanceMatrix({
          origins: [location],
          destinations: [destinationAddr],
          travelMode: google.maps.TravelMode.DRIVING,
          unitSystem: google.maps.UnitSystem.METRIC,
          avoidHighways: false,
          avoidTolls: false
        }, getDistance);

    }

    function getDistance(response, status)
    {
      if (status == "OK") {
        document.getElementById('DistanceFromOffice').value = response.rows[0].elements[0].distance.text;
        document.getElementById('DurationFromOffice').value = response.rows[0].elements[0].duration.text;
      } else {
        document.getElementById('DistanceFromOffice').value = '';
        document.getElementById('DurationFromOffice').value = '';
      }
    }

    $(document).ready(function(){
      $(document).on('change', '#officeAddSelect', function (e) {
        var destination = $('#autocomplete').val();
        if (destination == '') {
          return false;
        }

        var place = autocomplete.getPlace();

        if (typeof(place) == 'undefined') {
          return false;
        }

        office_location = $('#officeAddSelect option:selected').text();

        calculateDistances(place.formatted_address);

      });
    });

    </script>

  </body>
</html>
