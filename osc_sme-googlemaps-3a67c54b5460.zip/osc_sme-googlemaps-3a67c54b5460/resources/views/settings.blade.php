<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="cache-control" content="no-cache" />
		<meta name="viewport" content="width=device-width, initial-scale=0.1">
		<title>Direct SMS Settings</title>
		<!-- Style sheets-->
		<link href="theme/font-awesome/css/font-awesome.css" rel="stylesheet">
	    <link href="theme/Ionicons/css/ionicons.css" rel="stylesheet">
	    <link href="theme/SpinKit/spinkit.css" rel="stylesheet">
	    <link rel="stylesheet" href="theme/css/amanda.css">

	    <!--Scripts-->
	    <script src="theme/jquery/jquery.js"></script>
	    <script src="theme/popper.js/popper.js"></script>
	    <script src="theme/bootstrap/bootstrap.js"></script>
	    <script src="theme/jquery-ui/jquery-ui.js"></script>
	    <script src="theme/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>
	    <script src="theme/jquery-toggles/toggles.min.js"></script>

		<!-- For JQuery Tabs-->		
		
		<script src="theme/js/amanda.js"></script>
		<script type="text/javascript" src="lib/handlebars.js"></script> 
		<script type="text/javascript" src="lib/ZohoEmbededAppSDK.min.js"></script>   
		<script src="lib/customFunction.js"></script>
		<script>
			$(document).ready(function(){
				setTimeout(function(){
					$('#loadingSetting').hide();
					$('#settingContent').slideDown('slow');
					$('#settingFooter').show();
				}, 3000);

				var directSMSUserName, directSMSUserPassword, replySMSNotifyTo, directSMSType, directSMSSenderId, unicodeSMSSupport, SendSMSToDeal, incomingWebHookURL, templasteOptions;

				ZOHO.embeddedApp.init().then(function(){
					ZOHO.CRM.API.getOrgVariable("directsms.directSMSUserName").then(function(data){
						var newOrg 			= (data.Success);
						directSMSUserName 	= newOrg.Content;
						if(directSMSUserName != null){
							$("#directSMSUserName").val(directSMSUserName);
						}			
					});

					ZOHO.CRM.API.getOrgVariable("directsms.directSMSUserPassword").then(function(data){
						var newOrg 				= (data.Success);
						directSMSUserPassword 	= newOrg.Content;
						if(directSMSUserPassword != null){
							$("#directSMSUserPassword").val(directSMSUserPassword);
						}	
					});

					ZOHO.CRM.API.getOrgVariable("directsms.defaultEventReminderTemplateID").then(function(data){
						var newOrg 						= (data.Success);
						defaultEventReminderTemplateID 	= newOrg.Content;
						if(defaultEventReminderTemplateID != null){
							//Load all SMS Templates
							ZOHO.CRM.API.searchRecord({Entity:"directsms.SMS_Templates",Type:"criteria",Query:"(directsms.Module_Name:equals:Events)"}).then(function(allSMSTemplates){
								var smsTemplates 	= allSMSTemplates.data;
								$.each(smsTemplates, function(stIndex,templateInfo){
									$.each(templateInfo, function(fieldName, fieldValue){
										if(fieldName == "id"){
											templasteOptions	= templasteOptions+'<option value="'+fieldValue+'">'+templateInfo.Name+'</option>';
										}
									});
								});
								$("#defaultEventReminderTemplateID").html(templasteOptions);
								$("#defaultEventReminderTemplateID").val(defaultEventReminderTemplateID);
							});
							
						}	
					});

					ZOHO.CRM.API.getOrgVariable("directsms.replySMSNotifyTo").then(function(data){
						var newOrg 				= (data.Success);
						replySMSNotifyTo 	= newOrg.Content;
						if(replySMSNotifyTo != null){
							$("#replySMSNotifyTo").val(replySMSNotifyTo);

							$(".replySMSNotifyTo").css({"box-shadow":"none"});
							$(".replySMSNotifyTo").addClass('disabled');	
							$(".replySMSNotifyTo").removeClass('active');

							var procreplySMSNotifyTo = replySMSNotifyTo.replace(" ", "");

							$("#"+procreplySMSNotifyTo).removeClass('disabled');
							$("#"+procreplySMSNotifyTo).addClass('active');
							$("#"+procreplySMSNotifyTo).css({"box-shadow":"0 0 0 3px rgba(28, 179, 134, 0.5)"});
						}	
					});
					
					ZOHO.CRM.API.getOrgVariable("directsms.directSMSType").then(function(data){
						var newOrg 				= (data.Success);
						directSMSType 	= newOrg.Content;
						if(directSMSType != null){
							$("#directSMSType").val(directSMSType);
							if(directSMSType == "2-way"){
								$("#directSMSSenderIdContent").hide();
							}

							$(".directSMSType").css({"box-shadow":"none"});
							$(".directSMSType").addClass('disabled');	
							$(".directSMSType").removeClass('active');

							$("#"+directSMSType).removeClass('disabled');
							$("#"+directSMSType).addClass('active');
							$("#"+directSMSType).css({"box-shadow":"0 0 0 3px rgba(28, 179, 134, 0.5)"});
						}	
					});
					
					ZOHO.CRM.API.getOrgVariable("directsms.directSMSSenderId").then(function(data){
						var newOrg 				= (data.Success);
						directSMSSenderId 	= newOrg.Content;
						if(directSMSSenderId != null){
							$("#directSMSSenderId").val(directSMSSenderId);
						}	
					});
					
					ZOHO.CRM.API.getOrgVariable("directsms.unicodeSMSSupport").then(function(data){
						var newOrg 				= (data.Success);
						unicodeSMSSupport 	= newOrg.Content;
						if(unicodeSMSSupport != null){
							$("#unicodeSMSSupport").val(unicodeSMSSupport);

							$(".unicodeSMSSupport").css({"box-shadow":"none"});
							$(".unicodeSMSSupport").addClass('disabled');	
							$(".unicodeSMSSupport").removeClass('active');

							$("#"+unicodeSMSSupport).removeClass('disabled');
							$("#"+unicodeSMSSupport).addClass('active');
							$("#"+unicodeSMSSupport).css({"box-shadow":"0 0 0 3px rgba(28, 179, 134, 0.5)"});
						}	
					});

					ZOHO.CRM.API.getOrgVariable("directsms.SendSMSToDeal").then(function(data){
						var newOrg 				= (data.Success);
						SendSMSToDeal 	= newOrg.Content;
						if(SendSMSToDeal != null){
							$("#SendSMSToDeal").val(SendSMSToDeal);

							$(".SendSMSToDeal").css({"box-shadow":"none"});
							$(".SendSMSToDeal").addClass('disabled');	
							$(".SendSMSToDeal").removeClass('active');

							$("#"+SendSMSToDeal).removeClass('disabled');
							$("#"+SendSMSToDeal).addClass('active');
							$("#"+SendSMSToDeal).css({"box-shadow":"0 0 0 3px rgba(28, 179, 134, 0.5)"});
						}	
					});

					ZOHO.CRM.API.getOrgVariable("directsms.incomingWebHookURL").then(function(data){
						var newOrg 				= (data.Success);
						incomingWebHookURL 	= newOrg.Content;
						if(incomingWebHookURL != null){
							$("#incomingWebHookURL").html(incomingWebHookURL);
						}	
					});

					ZOHO.CRM.API.getOrgVariable("directsms.SMSStatusCallbackUrl").then(function(data){
						var newOrg 				= (data.Success);
						SMSStatusCallbackUrl 	= newOrg.Content;
						if(SMSStatusCallbackUrl != null){
							$("#SMSStatusCallbackUrl").html(SMSStatusCallbackUrl);
						}	
					});

					ZOHO.CRM.API.getOrgVariable("directsms.personalizedSMSUrl").then(function(data){
						var newOrg 				= (data.Success);
						personalizedSMSUrl 	= newOrg.Content;
						if(personalizedSMSUrl != null){
							$("#personalizedSMSUrl").html(personalizedSMSUrl);
						}	
					});


				});

				$("#saveSettings").on('click', function(){
					setTimeout(function(){
						$("#errorBlock").slideUp('slow');
						$("#successMessage").slideUp('slow');
					},3000);
					var directSMSUserNameVal	= $("#directSMSUserName").val();
					var directSMSUserPasswordVal= $("#directSMSUserPassword").val();
					var replySMSNotifyToVal		= $("#replySMSNotifyTo").val();
					var directSMSTypeVal		= $("#directSMSType").val();
					var directSMSSenderIdVal	= $("#directSMSSenderId").val();
					var unicodeSMSSupportVal	= $("#unicodeSMSSupport").val();
					var SendSMSToDealVal		= $("#SendSMSToDeal").val();

					if(directSMSUserNameVal == ""){
						$("#directSMSUserName").css({"border": "1px solid #dc3545"});
						$("#errorBlock").html('<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong class="d-block d-sm-inline-block-force">DirectSMS User Name!</strong> You have not filled in DirectSMS User Name.');
						$("#errorBlock").slideDown('slow');
						$("#directSMSUserName").focus();
						return false;
					}

					if(directSMSUserPasswordVal == ""){
						$("#directSMSUserPassword").css({"border": "1px solid #dc3545"});
						$("#errorBlock").html('<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong class="d-block d-sm-inline-block-force">DirectSMS User Password!</strong> You have not filled in DirectSMS User Password.');
						$("#errorBlock").slideDown('slow');
						$("#directSMSUserPassword").focus();
						return false;
					}

					if(directSMSTypeVal == "1-way" && directSMSSenderIdVal == ""){
						$("#directSMSSenderId").css({"border": "1px solid #dc3545"});
						$("#errorBlock").html('<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong class="d-block d-sm-inline-block-force">DirectSMS Sender Id!</strong> You have not filled in DirectSMS Sender Id.');
						$("#errorBlock").slideDown('slow');
						$("#directSMSSenderId").focus();
						return false;
					}

					//update extension value
					$("#processingSetting").slideDown('slow');
					ZOHO.CRM.CONNECTOR.invokeAPI("crm.set",{"apiname":"directsms.directSMSUserName","value":directSMSUserNameVal}).then(function(response){
						//var response = JSON.parse(data);
						if(response.status_code == 200){
							ZOHO.CRM.CONNECTOR.invokeAPI("crm.set",{"apiname":"directsms.directSMSUserPassword","value":directSMSUserPasswordVal}).then(function(response){
								//var response = JSON.parse(data);
								if(response.status_code == 200){
									ZOHO.CRM.CONNECTOR.invokeAPI("crm.set",{"apiname":"directsms.replySMSNotifyTo","value":replySMSNotifyToVal}).then(function(response){
										//var response = JSON.parse(data);
										if(response.status_code == 200){
											ZOHO.CRM.CONNECTOR.invokeAPI("crm.set",{"apiname":"directsms.directSMSType","value":directSMSTypeVal}).then(function(data){
												//var response = JSON.parse(data);
												if(response.status_code == 200){
													ZOHO.CRM.CONNECTOR.invokeAPI("crm.set",{"apiname":"directsms.directSMSSenderId","value":directSMSSenderIdVal}).then(function(response){
														//var response = JSON.parse(data);
														if(response.status_code == 200){
															ZOHO.CRM.CONNECTOR.invokeAPI("crm.set",{"apiname":"directsms.unicodeSMSSupport","value":unicodeSMSSupportVal}).then(function(response){
																//var response = JSON.parse(data);
																if(response.status_code == 200){
																	ZOHO.CRM.CONNECTOR.invokeAPI("crm.set",{"apiname":"directsms.SendSMSToDeal","value":SendSMSToDealVal}).then(function(response){
																		//var response = JSON.parse(data);
																		if(response.status_code == 200){
																			$("#processingSetting").hide();
																			$("#successMessage").slideDown('slow');
																		}
																		else{
																			$("#errorBlock").html('<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong class="d-block d-sm-inline-block-force">Opps!</strong> '+response.response+' Please refresh your browser and try again.');
																			$("#errorBlock").slideDown('slow');
																		}
																	});																	
																}
																else{
																	$("#errorBlock").html('<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong class="d-block d-sm-inline-block-force">Opps!</strong> '+response.response+' Please refresh your browser and try again.');
																	$("#errorBlock").slideDown('slow');
																}
															});
														}
														else{
															$("#errorBlock").html('<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong class="d-block d-sm-inline-block-force">Opps!</strong> '+response.response+' Please refresh your browser and try again.');
															$("#errorBlock").slideDown('slow');
														}
													});
												}
												else{
													$("#errorBlock").html('<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong class="d-block d-sm-inline-block-force">Opps!</strong> '+response.response+' Please refresh your browser and try again.');
													$("#errorBlock").slideDown('slow');
												}
											});
										}
										else{
											$("#errorBlock").html('<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong class="d-block d-sm-inline-block-force">Opps!</strong> '+response.response+' Please refresh your browser and try again.');
											$("#errorBlock").slideDown('slow');
										}
									});
								}
								else{
									$("#errorBlock").html('<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong class="d-block d-sm-inline-block-force">Opps!</strong> '+response.response+' Please refresh your browser and try again.');
									$("#errorBlock").slideDown('slow');
								}
							});
						}
						else{
							$("#errorBlock").html('<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong class="d-block d-sm-inline-block-force">Opps!</strong> '+response.response+' Please refresh your browser and try again.');
							$("#errorBlock").slideDown('slow');
						}
					});
				});

				$(".SendSMSToDeal").on('click', function(){
					var SendSMSToDealVal = $(this).attr('id');
					$(".SendSMSToDeal").css({"box-shadow":"none"});
					$(".SendSMSToDeal").addClass('disabled');	
					$(".SendSMSToDeal").removeClass('active');

					$(this).removeClass('disabled');
					$(this).addClass('active');
					$(this).css({"box-shadow":"0 0 0 3px rgba(28, 179, 134, 0.5)"});

					$("#SendSMSToDeal").val(SendSMSToDealVal);
				});

				$(".unicodeSMSSupport").on('click', function(){
					var unicodeSMSSupportVal = $(this).attr('id');

					$(".unicodeSMSSupport").css({"box-shadow":"none"});
					$(".unicodeSMSSupport").addClass('disabled');	
					$(".unicodeSMSSupport").removeClass('active');

					$(this).removeClass('disabled');
					$(this).addClass('active');
					$(this).css({"box-shadow":"0 0 0 3px rgba(28, 179, 134, 0.5)"});

					$("#unicodeSMSSupport").val(unicodeSMSSupportVal);
				});

				$(".directSMSType").on('click', function(){
					var directSMSTypeVal = $(this).attr('id');

					$(".directSMSType").css({"box-shadow":"none"});
					$(".directSMSType").addClass('disabled');	
					$(".directSMSType").removeClass('active');

					$(this).removeClass('disabled');
					$(this).addClass('active');
					$(this).css({"box-shadow":"0 0 0 3px rgba(28, 179, 134, 0.5)"});

					$("#directSMSType").val(directSMSTypeVal);

					if(directSMSTypeVal == "1-way"){
						$("#directSMSSenderIdContent").slideDown("slow");
					}else if(directSMSTypeVal == "2-way"){
						$("#directSMSSenderId").val('');
						$("#directSMSSenderIdContent").slideUp("slow");
					}
				});

				$("#directSMSSenderId").on('keyup', function(){
					if($(this).val() !=""){
						$("#directSMSSenderId").css({"border": "1px solid rgba(0, 0, 0, 0.15)"});
					}
					else{
						$("#directSMSSenderId").css({"border": "1px solid #dc3545"});
					}
				});
				$("#directSMSUserPassword").on('keyup', function(){
					if($(this).val() !=""){
						$("#directSMSUserPassword").css({"border": "1px solid rgba(0, 0, 0, 0.15)"});
					}
					else{
						$("#directSMSUserPassword").css({"border": "1px solid #dc3545"});
					}
				});
				$("#directSMSUserName").on('keyup', function(){
					if($(this).val() !=""){
						$("#directSMSUserName").css({"border": "1px solid rgba(0, 0, 0, 0.15)"});
					}
					else{
						$("#directSMSUserName").css({"border": "1px solid #dc3545"});
					}
				});
				
			});			
		</script>
	</head>
	<body>
		<div class="am-mainpanel">
	      	<div class="am-pagebody" id="settingContent">
		        <div class="card pd-20 pd-sm-40 form-layout form-layout-4">
		          	<h6 class="card-body-title">DirectSMS Settings</h6>
		         	<p class="mg-b-20 mg-sm-b-30">In order to send SMS, your Burst SMS setting is very important. Please fill all the value as your desireation. Any wrong setting your SMS will not send.</p>
		          	<div class="form-layout">
		          		<div class="alert alert-success" role="alert" id="successMessage">
				            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				            <strong class="d-block d-sm-inline-block-force">Well done!</strong> You successfully updated the data information.
				        </div><!-- alert -->
		          		<div class="alert alert-danger mg-b-20" role="alert" id="errorBlock"></div><!-- alert -->
		          		<div class="row">
	                		<label class="col-sm-2 form-control-label">DirectSMS User Name: <span class="tx-danger">*</span></label>
	                		<div class="col-sm-3 mg-t-10 mg-sm-t-0">
	                  			<input type="text" id="directSMSUserName" name="directSMSUserName" class="form-control" placeholder="Enter direct SMS user name" required>
	                		</div>
	              		</div><!-- row -->

		            	<div class="row mg-t-10">
	                		<label class="col-sm-2 form-control-label">DirectSMS User Password: <span class="tx-danger">*</span></label>
	                		<div class="col-sm-3 mg-t-10 mg-sm-t-0">
	                  			<input type="text" id="directSMSUserPassword" name="directSMSUserPassword"  class="form-control" placeholder="Enter direct SMS user password">
	                		</div>
	              		</div><!-- row -->	

	              		<div class="row mg-t-5 mg-b-5">
	                		<label class="col-sm-2 form-control-label">Event Reminder Template:</label>
	                		<div class="col-sm-3 mg-t-5 mg-sm-t-0  mg-b-10">
	                			<select id="defaultEventReminderTemplateID" name="defaultEventReminderTemplateID" class="form-control" data-placeholder="Choose Event Reminder Template"></select>
	                		</div>
	              		</div><!-- row -->            	
	              		
		            	<div class="row mg-t-10">
	                		<label class="col-sm-2 form-control-label">DirectSMS Type: <span class="tx-danger">*</span></label>
	                		<div class="col-sm-3 mg-t-5 mg-sm-t-0">
	                			<button class="btn btn-teal disabled btn-block mg-b-10 directSMSType" id="1-way">One Way (Only Sending)</button>
	                		</div>
	                		<div class="col-sm-3 mg-t-5 mg-sm-t-0">
	                			<button class="btn btn-teal disabled btn-block mg-b-10 directSMSType" id="2-way">2 Way (Sending & Receiving)</button>
	                		</div>
	                		<input type="hidden" id="directSMSType" name="directSMSType">
	              		</div><!-- row -->

	              		<div class="row mg-t-5 mg-b-5" id="directSMSSenderIdContent">
	                		<label class="col-sm-2 form-control-label">DirectSMS Sender Id:</label>
	                		<div class="col-sm-3 mg-t-5 mg-sm-t-0  mg-b-10">
	                  			<input type="text" id="directSMSSenderId" name="directSMSSenderId" class="form-control" placeholder="Enter direct SMS sender ID">
	                		</div>
	              		</div><!-- row -->

	              		<div class="row mg-t-5">
	                		<label class="col-sm-2 form-control-label">Reply SMS Notify To: <span class="tx-danger">*</span></label>
	                		<div class="col-sm-3 mg-t-5 mg-sm-t-0">
	                			<button class="btn btn-teal disabled btn-block mg-b-10 replySMSNotifyTo" id="RecordOwner">Record Owner</button>
	                		</div>
	                		<div class="col-sm-3 mg-t-5 mg-sm-t-0">
	                			<button class="btn btn-teal disabled btn-block mg-b-10 replySMSNotifyTo" id="WhoHasSent">Who Has Sent</button>
	                		</div>
	                		<input type="hidden" id="replySMSNotifyTo" name="replySMSNotifyTo">
	              		</div><!-- row -->
		            	<div class="row mg-t-5">
	                		<label class="col-sm-2 form-control-label">Unicode SMS Support: <span class="tx-danger">*</span></label>
	                		<div class="col-sm-3 mg-t-5 mg-sm-t-0">
	                			<button class="btn btn-teal disabled btn-block mg-b-10 unicodeSMSSupport" id="true">Yes</button> 
	                		</div>
	                		<div class="col-sm-3 mg-t-5 mg-sm-t-0">
	                			<button class="btn btn-teal disabled btn-block mg-b-10 unicodeSMSSupport" id="false">No</button>
	                		</div>
	                		<input type="hidden" id="unicodeSMSSupport" name="unicodeSMSSupport">
	              		</div><!-- row -->

		            	<div class="row mg-t-5">
	                		<label class="col-sm-2 form-control-label">Send SMS to Deals: <span class="tx-danger">*</span></label>
	                		<div class="col-sm-3 mg-t-5 mg-sm-t-0">
            					<button class="btn btn-teal disabled btn-block mg-b-10 SendSMSToDeal" id="PrimaryContactOnly">Primary Contact Only</button>              
	                		</div>
	                		<div class="col-sm-3 mg-t-5 mg-sm-t-0">
	                  			<button class="btn btn-teal disabled btn-block mg-b-10 SendSMSToDeal" id="AssociatedAllContacts">Associated All Contacts</button>
	                		</div>
	                		<input type="hidden" id="SendSMSToDeal" name="SendSMSToDeal">
	              		</div><!-- row -->

		            	<div class="row mg-t-5">
	                		<label class="col-sm-2 form-control-label">Incoming WebHook URL:</label>
	                		<div class="col-sm-10 mg-t-10 mg-sm-t-0" style="word-break: break-all;">
	                  			<label class="form-control-label" style="color:#868ba1" id="incomingWebHookURL"></label>
	                		</div>
	              		</div><!-- row -->

		            	<div class="row mg-t-5">
	                		<label class="col-sm-2 form-control-label">SMS Status Callback Url:</label>
	                		<div class="col-sm-10 mg-t-10 mg-sm-t-0" style="word-break: break-all;">
	                  			<label class="form-control-label" style="color:#868ba1" id="SMSStatusCallbackUrl"></label>
	                		</div>
	              		</div><!-- row -->

		            	<div class="row mg-t-5">
	                		<label class="col-sm-2 form-control-label">Personalized SMS Url:</label>
	                		<div class="col-sm-10 mg-t-10 mg-sm-t-0" style="word-break: break-all;">
	                  			<label class="form-control-label" style="color:#868ba1" id="personalizedSMSUrl"></label>
	                		</div>
	              		</div><!-- row -->

		            	<div class="form-layout-footer tx-center mg-t-20">
		              		<button class="btn btn-info mg-r-5" id="saveSettings"><i class="fa fa-gear mg-r-10"></i> Save Settings</button>
		            	</div><!-- form-layout-footer -->
		          	</div><!-- form-layout -->
		          	<div id="processingSetting">
		          		<div class="d-flex ht-300 pos-relative align-items-center">
         					<div class="sk-folding-cube">
	               			 	<div class="sk-cube1 sk-cube"></div>
	                			<div class="sk-cube2 sk-cube"></div>
	                			<div class="sk-cube4 sk-cube"></div>
	                			<div class="sk-cube3 sk-cube"></div>
	            			</div>
       	 				</div><!-- d-flex -->
       	 			</div>
		        </div><!-- card -->		        
	    	</div><!-- am-pagebody -->
	      	<div class="am-footer tx-right" id="settingFooter">
	        	<span><a href="https://www.oscillosoft.com.au/" target="_blank"><img src="images/powerbyb.png" alt="Oscillosoft Pty Ltd"></a></span>
	      	</div><!-- am-footer -->	      	
   	 	</div><!-- am-mainpanel -->
   	 	<div class="col-md-12 col-xl-12 mg-t-200 mg-xl-t-0" id="loadingSetting">
        	<div class="d-flex ht-300 pos-relative align-items-center">
         		<div class="sk-folding-cube">
	                <div class="sk-cube1 sk-cube"></div>
	                <div class="sk-cube2 sk-cube"></div>
	                <div class="sk-cube4 sk-cube"></div>
	                <div class="sk-cube3 sk-cube"></div>
	            </div>
       	 	</div><!-- d-flex -->
      	</div><!-- col-4 -->
    </body>   
</html>
