@extends('google.master')

@section('button_name', 'Add To Contact')

@section('map-content')
    <div class="container-fluid">
        <div class="col">
            <div id="locationField" class="form-group">
                <input id="autocomplete" class="form-control" placeholder="What you're looking for" onFocus="geolocate()" type="text"></input>
            </div>

            <div class="row form-group">
                <div class="col">
                    <select class="custom-select" id="StateSelect">
                        <option value="MA">Mailing Address</option>
                        <option value="OA">Other Address</option>
                    </select>
                </div>
                <div class="col">
                    <select class="custom-select" id="officeAddSelect">
                    </select>
                </div>

            </div>

            <table id="address" class="table table-striped table-dark">
                <tr>
                    <td>Street address</td>
                    <td class="slimField">
                        <input class="form-control" id="street_number" disabled="true">
                    </td>
                    <td class="wideField" colspan="2">
                        <input class="form-control" id="route" disabled="true">
                    </td>
                </tr>
                <tr>
                    <td>City</td>
                    <!-- Note: Selection of address components in this example is typical.
                        You may need to adjust it for the locations relevant to your app. See
                        https://developers.google.com/maps/documentation/javascript/examples/places-autocomplete-addressform
                    -->
                    <td class="wideField" colspan="3">
                        <input class="form-control" id="locality" disabled="true">
                    </td>
                </tr>
                <tr>
                    <td class="label">State</td>
                    <td class="slimField">
                        <input class="form-control" id="administrative_area_level_1" disabled="true">
                    </td>
                    <td class="label">Zip code</td>
                    <td class="wideField">
                        <input class="form-control" id="postal_code" disabled="true">
                    </td>
                </tr>
                <tr>
                    <td class="label">Country</td>
                    <td class="wideField" colspan="3">
                        <input class="form-control" id="country" disabled="true">
                    </td>
                </tr>

                <tr>
                    <td class="label">Distance</td>
                    <td class="slimField">
                        <input class="form-control" id="DistanceFromOffice" disabled="true">
                    </td>
                    <td class="label">Duration</td>
                    <td class="wideField">
                        <input class="form-control" id="DurationFromOffice" disabled="true">
                    </td>
                </tr>

                <tr>
                    <td class="label">Latitude</td>
                    <td class="slimField">
                        <input class="form-control" id="latitude" disabled="true">
                    </td>
                    <td class="label">Longitude</td>
                    <td class="wideField">
                        <input class="form-control" id="longitude" disabled="true">
                    </td>
                </tr>

            </table>

            <div class="row">
                <div class="col">
                    <button class="btn btn-primary" id="add_address">@yield('button_name')</button>
                </div>
            </div>

        </div>
    </div>
@endsection

@section('javascript_module')
    <script src="js/zoho-contact-client.js"></script>
@endsection