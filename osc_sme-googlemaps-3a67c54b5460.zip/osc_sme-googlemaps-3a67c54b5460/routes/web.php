<?php

Route::get('/', function () {
    return view('welcome');
});

Route::get('/lead', 'MapController@lead')->name('lead');
Route::get('/account', 'MapController@account')->name('account');
Route::get('/contact', 'MapController@contact')->name('contact');
Route::get('/setting', 'MapController@setting')->name('setting');
Route::get('/test', 'MapController@test')->name('test');
