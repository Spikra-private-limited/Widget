<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MapController extends Controller
{
    public function lead()
    {
    	return view('lead');
    }
    public function account()
    {
    	return view('account');
    }
    public function contact()
    {
    	return view('contact');
    }
    public function setting()
    {
        return view('setting');
    }
    public function test()
    {
        return "Test Done.";
    }
}
