$(document).ready(function(){
    var leadId;
    ZOHO.embeddedApp.on("PageLoad",function(data){
        leadId = data.EntityId;
    });

    ZOHO.embeddedApp.init().then(function(){

        ZOHO.CRM.API.getOrgVariable("Google_Api_Key").then(function(data){
            var newOrg 		= (data.Success);
            google_api_key 	= newOrg.Content;
            if(google_api_key != null){
                $("#xbestos").attr('src', 'https://maps.googleapis.com/maps/api/js?key='+google_api_key+'&libraries=places&callback=initAutocomplete');
            }
        });

        ZOHO.CRM.API.getOrgVariable("Office_Location").then(function(data){
            var newOrg 		= (data.Success);
            Office_Location 	= newOrg.Content;
            if(Office_Location != null){
                officeLocationJson = JSON.parse(Office_Location);

                var ofc_index = 1;
                var option = '';
                while (true) {
                    var ofc_add_obj = '';

                    if (!officeLocationJson.hasOwnProperty(ofc_index)) {
                        break;
                    }

                    // Office Location Add
                    ofc_add_obj = officeLocationJson[ofc_index];
                    console.log();
                    var add_string = ((ofc_add_obj.Street.length > 0) ? ofc_add_obj.Street+', ' : '') + ((ofc_add_obj.City.length > 0) ? ofc_add_obj.City+', ' : '') + ((ofc_add_obj.State.length > 0) ? ofc_add_obj.State+', ' : '') + ((ofc_add_obj.Country.length > 0) ? ofc_add_obj.Country : '');
                    add_string = add_string.replace(/,\s*$/, "");
                    option += "<option value='"+JSON.stringify(ofc_add_obj)+"'>"+add_string+"</option>";

                    ofc_index++;

                }

                $('#officeAddSelect').html(option);
            }
        });


    });
});
