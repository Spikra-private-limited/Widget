$(document).ready(function(){

    // Get Page Id on load of information

    var contactId;

    ZOHO.embeddedApp.on("PageLoad",function(data){
        contactId = data.EntityId;
    });

    ZOHO.embeddedApp.init().then(function(){

        ZOHO.CRM.API.getOrgVariable("Google_Api_Key").then(function(data){
            var newOrg 		= (data.Success);
            google_api_key 	= newOrg.Content;
            if(google_api_key != null){
                $("#xbestos").attr('src', 'https://maps.googleapis.com/maps/api/js?key='+google_api_key+'&libraries=places&callback=initAutocomplete');
            }
        });

        ZOHO.CRM.API.getOrgVariable("Office_Location").then(function(data){
            var newOrg 		= (data.Success);
            Office_Location 	= newOrg.Content;
            if(Office_Location != null){
                officeLocationJson = JSON.parse(Office_Location);

                var ofc_index = 1;
                var option = '';
                while (true) {
                    var ofc_add_obj = '';

                    if (!officeLocationJson.hasOwnProperty(ofc_index)) {
                        break;
                    }

                    // Office Location Add
                    ofc_add_obj = officeLocationJson[ofc_index];
                    console.log();
                    var add_string = ((ofc_add_obj.Street.length > 0) ? ofc_add_obj.Street+', ' : '') + ((ofc_add_obj.City.length > 0) ? ofc_add_obj.City+', ' : '') + ((ofc_add_obj.State.length > 0) ? ofc_add_obj.State+', ' : '') + ((ofc_add_obj.Country.length > 0) ? ofc_add_obj.Country : '');
                    add_string = add_string.replace(/,\s*$/, "");
                    option += "<option value='"+JSON.stringify(ofc_add_obj)+"'>"+add_string+"</option>";

                    ofc_index++;

                }

                $('#officeAddSelect').html(option);
            }
        });


    });

    $(document).on('click', '#add_address', function(){

        var address = $('#StateSelect').val();
        var addressText = $('#StateSelect option:selected').text();

        var addressInfo = {};
        var street_no   = $('#street_number').val();
        var route       = $('#route').val();
        var state       = $('#administrative_area_level_1').val();
        var city        = $('#locality').val();
        var postal_code = $('#postal_code').val();
        var country     = $('#country').val();
        var distance    = $('#DistanceFromOffice').val();
        var duration    = $('#DurationFromOffice').val();

        street_no = street_no + ' ' + route;

        if (address == 'MA') {
            addressInfo = {
                'id'                : contactId + '',
                'Mailing_Street'    : street_no,
                'Mailing_State'     : state,
                'Mailing_City'      : city,
                'Mailing_Zip'       : postal_code,
                'Mailing_Country'   : country,
                'Mailing_Distance'  : distance,
                'Mailing_Duration'  : duration,
            };
        } else if (address == 'OA') {
            addressInfo = {
                'id'              : contactId + '',
                'Other_Street'    : street_no,
                'Other_State'     : state,
                'Other_City'      : city,
                'Other_Zip'       : postal_code,
                'Other_Country'   : country,
                'Other_Distance'  : distance,
                'Other_Duration'  : duration,
            };
        }

        if (addressInfo.hasOwnProperty('id')) {
            if (confirm("Are you sure want to add this address to "+addressText +"?")) {
                ZOHO.CRM.API.updateRecord({Entity:"Contacts",APIData:addressInfo})
                    .then(function(response){

                        if (response.data[0].code == "SUCCESS") {
                            ZOHO.CRM.UI.Popup.closeReload();
                        } else {
                            alert("Error occurred");
                        }

                    });
            }
        } else {
            alert("Error Occurred. Please try again later.");
            return false;
        }


    });


});

