$(document).ready(function()
    {
	ZOHO.embeddedApp.on("PageLoad", function(data)
     { 	 	
          console.log(data);    
	  	  console.log(data.EntityId);
		  
		  id= BigInt(data.EntityId).toString();
		  ZOHO.CRM.API.getRecord({Entity:"KAM_Targets",RecordID:id})
     .then(function(data1)
      {
	  console.log(data1);
	  });
	 });
	});