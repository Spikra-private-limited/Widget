$(document).ready(function() {
    let entityData = {};
    let eventArr = [];

    function isNull(str) {
        return str || '--';
    }
    ZOHO.embeddedApp.on('PageLoad', data => {
        entityData = data;
        let resizeWindow = ZOHO.CRM.UI.Resize({ width: '100%', height: '80%' });
        let relatedContacts = ZOHO.CRM.API.getRelatedRecords({ Entity: entityData.Entity, RecordID: entityData.EntityId, RelatedList: 'Contacts' })
            .then(contacts => {
                let contactsObjArr = contacts.data;
                let pushPromiseArr = [];
                if (contactsObjArr) {
                    pushPromiseArr.push(Promise.resolve());
                    $.each(contactsObjArr, function(k, v) {
                        let contactId = v.id;
                        pushPromiseArr.push(ZOHO.CRM.API.getRelatedRecords({ Entity: 'Contacts', RecordID: contactId, RelatedList: 'Events' }).then(data => {
                            let eventDataArr = data.data;
                            if (eventDataArr) {
                                $.each(eventDataArr, function(k, v) {
                                    eventArr.push({
                                        title: isNull(v.Event_Title),
                                        start: isNull(v.Start_DateTime),
                                        end: isNull(v.End_DateTime),
                                        // url: `https://crm.zoho.in/crm/org60004350648/tab/Activities/${v.id}?sub_module=Events`,
                                        // color: '#34a853',
                                        dataId: v.id
                                    });
                                });
                            }
                        }));
                    });
                    Promise.all(pushPromiseArr).then(() => {
                        $('#calendar').fullCalendar({
                            height: 700,
                            width: 400,
                            buttonText: {
                                today: 'Today',
                                month: 'Month',
                                week: 'Week',
                                day: 'Day',
                                list: 'List'
                            },
                            themeSystem: 'bootstrap4',
                            defaultView: 'month',
                            header: {
                                left: 'today prev,next',
                                center: 'title',
                                right: 'month,agendaWeek,agendaDay,listWeek'
                            },
                            navLinks: true,
                            eventLimit: true,
                            eventClick: function(event) {
                                window.open(`https://crm.zoho.in/crm/org60004350648/tab/Activities/${event.dataId}?sub_module=Events`)
                            },
                            events: eventArr
                        });
                    });
                } else {
                    $('#calendar').fullCalendar({
                        height: 700,
                        width: 400,
                        buttonText: {
                            today: 'Today',
                            month: 'Month',
                            week: 'Week',
                            day: 'Day',
                            list: 'List'
                        },
                        themeSystem: 'bootstrap4',
                        defaultView: 'month',
                        header: {
                            left: 'today prev,next',
                            center: 'title',
                            right: 'month,agendaWeek,agendaDay,listWeek'
                        },
                        navLinks: true,
                        eventLimit: true,
                        events: eventArr
                    });
                }
            });
        // $('#calendar').fullCalendar({
        //     height: 700,
        //     width: 400,
        //     buttonText: {
        //         today: 'Today',
        //         month: 'Month',
        //         week: 'Week',
        //         day: 'Day',
        //         list: 'List'
        //     },
        //     themeSystem: 'bootstrap4',
        //     defaultView: 'month',
        //     header: {
        //         left: 'today prev,next',
        //         center: 'title',
        //         right: 'month,agendaWeek,agendaDay,listWeek'
        //     },
        //     navLinks: true,
        //     eventLimit: true,
        //     events: eventArr
        // });
    });
    ZOHO.embeddedApp.init();
});